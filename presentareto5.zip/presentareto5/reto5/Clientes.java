import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Clientes {
    
    public static void IngresarClientes() throws SQLException{
        String sql = "insert into Clientes (Alias,Nombres_cliente,Apellidos_cliente,Email,Celular_cliente,Fecha_de_nacimiento_cliente,contraseña_cliente) values (?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement sentencia = Home.conexion().prepareStatement(sql);
        
        System.out.print("Alias: ");
        String Alias = Home.sc.nextLine();
        sentencia.setString(1, Alias);
        
        System.out.print("Nombres: ");
        String nombre = Home.sc.nextLine();
        sentencia.setString(2, nombre);
        
        System.out.print("Apellidos: ");
        String apellido = Home.sc.nextLine();
        sentencia.setString(3, apellido);
        
        System.out.print("Email: ");
        String email = Home.sc.nextLine();
        sentencia.setString(4, email);
        
        System.out.print("Celular cliente: ");
        String Celular_cliente = Home.sc.nextLine();
        sentencia.setString(5, Celular_cliente);
        
        System.out.print("Fecha de nacimiento: ");
        String Fecha_de_nacimiento_cliente = Home.sc.nextLine();
        sentencia.setString(6, Fecha_de_nacimiento_cliente);
        
        System.out.print("Contraseña: ");
        int contraseña_cliente = Home.sc.nextInt();
        sentencia.setInt(7, contraseña_cliente);
        Home.sc.nextLine();
        
        int Insertadas = sentencia.executeUpdate();
        if (Insertadas > 0) {
            System.out.println("Registros guardados exitosamente");
        }
    }
}
