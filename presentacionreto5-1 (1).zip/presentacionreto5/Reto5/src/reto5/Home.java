import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;



public class Home {
    public static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        menu();
    }
    
    public static void menu(){
        try{
            System.out.println("******************************\n"+
                   "***** RETO5 CRUD MYSQL   *****\n"+
                    "******************************\n"+
                    "-------------------------------------------------\n"+
                    "1. Ingresar datos en tabla Tipo_de_Vehiculo.\n"+
                    "2. Ingresar datos en tabla Bicicleta.\n"+
                    "3. Ingresar datos en tabla Proveedor_motor.\n"+
                    "4. Ingresar datos en tabla Motocicleta_Electrica.\n"+
                    "5. Ingresar datos en tabla Clientes.\n"+
                    "6. Ingresar datos en tabla Registro_intdecompra.\n"+
                    "-------------------------------------------------\n"+
                    "7. Modificar Año de Bicicleta.\n"+
                    "8. Modificar Telefono de Clientes.\n"+
                    "9. Borrar intención de Registro_intdecompra.\n"+
                    "-------------------------------------------------\n"+
                    "10. Listado de Fabricantes.\n"+
                    "11. Bicicletas estrenadas posterior del 2019.\n"+
                    "12. Motocicletas Electricas con motor Auteco.\n"+
                    "13. Fabricante con intencion de compra del cliente Lucky\n"+
                    "14. Clientes con intencion de compra de la bicicleta Yeti\n"+
                    "15. Bicicletas fabricadas posterior del año 2019"+
                    "-------------------------------------------------\n"+
                    "ingrese un numero diferente para salir"+
                    "-------------------------------------------------\n"
                );
                System.out.print(">> ");
                String input = sc.nextLine();
                byte opcion = Byte.parseByte (input);
                
                switch(opcion){
                    case 1: 
                        Tipo_de_Vehiculo.IngresarTipodevehiculo();
                        break;
                    case 2: 
                        Bicicleta.IngresarBicicleta();
                        break;
                    case 3: 
                        Proveedor_motor.IngresarProveedormotor();
                        break;
                    case 4: 
                        Motocicleta_Electrica.IngresarMotocicleta_Electrica();
                        break;
                    case 5: 
                        Clientes.IngresarClientes();
                        break;
                    case 6: 
                        Registro_intdecompra.IngresarRegistro_intdecompra();
                        break;
                    case 7: 
                        modificaciones.Modificaraño();
                        break;
                    case 8: 
                        modificaciones.Modificarcliente();
                        break;
                    case 9: 
                        modificaciones.borrarregistro();
                        break;
                    case 10: 
                        Consultas.consultafabricantes();
                        break;
                    case 11: 
                        Consultas.consultainformacionbici();
                        break;
                    case 12: 
                        Consultas.consultafabircantemoto();
                       break;
                    case 13: 
                        Consultas.consultaintencioncompra();
                        break;
                    case 14: 
                        Consultas.consultaintcompyeti();
                      break;  
                    case 15: 
                        Consultas.consultaañofab();
                        break;
                    default: 
                        System.out.println("Gracias por su tiempo");
                }         
        }catch(Exception e){
            System.out.println("Gracias por su tiempo");
        }
    }
    
    public static Connection conexion(){
        String dbURL = "jdbc:mysql://127.0.0.1:3306/reto4";
        String User = "root";
        String password = "9310";
        Connection conex = null;
        try {
            conex = DriverManager.getConnection(dbURL, User, password);
            if (conex != null){
                System.out.println("*** en coneccion ***");
                System.out.println("********************");
            }
        }catch (SQLException error){
            System.out.println("Error: "
                    + error.getErrorCode() + " " + error.getMessage());
        }
        return conex;
        
    }
    
}
