import java.sql.PreparedStatement;
import java.sql.SQLException;


public class modificaciones {
 
    public static void Modificaraño() throws SQLException {
        String sql = "UPDATE Bicicleta SET Año_de_construccion =? WHERE IdBicicleta =?";
        PreparedStatement senBici = Home.conexion().prepareStatement(sql);
        System.out.println("Ingrese fabricante y año a modificar:");
        
        System.out.println("Fabricante: ");
        int Tipo_de_Vehiculo = Home.sc.nextInt();
        senBici.setInt(2,Tipo_de_Vehiculo);
        
        System.out.println("Año: ");
        int Año_de_construccion = Home.sc.nextInt();
        senBici.setInt(1, Año_de_construccion);
        Home.sc.nextLine();

        int filasIns = senBici.executeUpdate();
        if (filasIns > 0) {
            System.out.println("Se modificó correctamente");    
        }
    } 
    public static void Modificarcliente() throws SQLException {
        String sql = "UPDATE clientes SET Celular_cliente =? WHERE alias =?";
        PreparedStatement sentencia = Home.conexion().prepareStatement(sql);
        System.out.println("Ingrese el alias y el nuevo número de celular.");
        
        System.out.println("Alias: ");
        String Alias = Home.sc.nextLine();
        sentencia.setString(2, Alias);
        
        System.out.println("Celular: ");
        String Celular_cliente = Home.sc.nextLine();
        sentencia.setString(1, Celular_cliente);
        
        int filasIns = sentencia.executeUpdate();
        if (filasIns > 0) {
            System.out.println("Se modificó correctamente");
        }
    }
    public static void borrarregistro() throws SQLException {
        String sql = "DELETE FROM Registro_intdecompra WHERE Reg_Alias =? AND Reg_Idtipodeveh =?";
        PreparedStatement senRegis = Home.conexion().prepareStatement(sql);
        System.out.println("Ingrese el Alias y el fabricante en el registro de intensión de compra");
        
        System.out.println("Alias: ");
        String Reg_Alias = Home.sc.nextLine();
        senRegis.setString(1, Reg_Alias);
        
        System.out.println("Fabricante: ");
        int Tipo_de_Vehiculo = Home.sc.nextInt();
        senRegis.setInt(2, Tipo_de_Vehiculo);
        
        int filasIns = senRegis.executeUpdate();    
        if (filasIns > 0) {
            System.out.println("El registro de intesión de compra se eliminó correctamente");
        }
    }
}