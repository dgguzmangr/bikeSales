import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Proveedor_motor {
    
    public static void IngresarProveedormotor() throws SQLException {
        String sqlProv = "INSERT INTO Proveedor_motor VALUES (?, ?, ?, ?)";
        PreparedStatement senProv = Home.conexion().prepareStatement(sqlProv);
        
        System.out.print("Id proveedor motor: ");
        int Idproveedormotor = Home.sc.nextInt();
        senProv.setInt(1, Idproveedormotor);
        Home.sc.nextLine();
        
        System.out.print("Nombre: ");
        String NombreProveedor = Home.sc.nextLine();
        senProv.setString(2, NombreProveedor);
        
        System.out.print("Dirección: ");
        String Direccionproveedor = Home.sc.nextLine();
        senProv.setString(3, Direccionproveedor);
        
        System.out.print("Teléfono: ");
        String Telefonoproveedor = Home.sc.nextLine();
        senProv.setString(4, Telefonoproveedor);
        
        int Insertadas = senProv.executeUpdate();
        if (Insertadas > 0) {
            System.out.println("Registros guardados exitosamente");
            System.out.println("--------------------------------");
        }
    }
}
