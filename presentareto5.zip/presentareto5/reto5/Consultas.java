import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Consultas {
    public static void consultafabricantes () throws SQLException{
        String sql = "select Nombre_del_fabricante from Tipo_de_Vehiculo order by Nombre_del_fabricante";
        Statement sentencia = Home.conexion().createStatement();
        ResultSet consulta = sentencia.executeQuery(sql);
        
        while (consulta.next()){
            String col1= consulta.getNString(1);
            System.out.println(col1);
        }  
    }  
    public static void consultainformacionbici () throws SQLException{
        String sql = "select b.Nombre_del_fabricante, a.Precio_unitario_bicicleta, a.Año_de_construccion from Bicicleta a inner join Tipo_de_Vehiculo b on a.IdBicicleta = b.Idtipodeveh where a.Año_de_construccion >= 2019 order by b.Nombre_del_fabricante;";
        Statement sentencia = Home.conexion().createStatement();
        ResultSet consulta = sentencia.executeQuery(sql);
        
        while (consulta.next()){
            String col1= consulta.getNString(1);
            String col2= consulta.getNString(2);
            int col3= consulta.getInt(3);
            System.out.println(col1 + " " + col2 + " " + col3);
        }   
    }  
    public static void consultafabircantemoto () throws SQLException{
        String sql = "select b.Nombre_del_fabricante, c.Proveedor_Nombre from Tipo_de_Vehiculo b, Proveedor_motor c  inner join Motocicleta_Electrica a on a.Doc_proveedormotor = c.Idproveedormotor where a.IdMoto = b.Idtipodeveh and c.Proveedor_Nombre = 'Auteco';";
        Statement sentencia = Home.conexion().createStatement();
        ResultSet consulta = sentencia.executeQuery(sql);
        
        while (consulta.next()){
            String col1= consulta.getNString(1);
            String col2= consulta.getNString(2);
            System.out.println(col1 + " " + col2);
        }   
    }  
    
    public static void consultaintencioncompra () throws SQLException{
        String sql = "select a.Nombre_del_fabricante from Tipo_de_Vehiculo a inner join Registro_intdecompra b on b.Reg_Idtipodeveh = a.Idtipodeveh where b.Reg_Alias = \"lucky\" order by a.Nombre_del_fabricante;";
        Statement sentencia = Home.conexion().createStatement();
        ResultSet consulta = sentencia.executeQuery(sql);
        
        while (consulta.next()){
            String col1= consulta.getNString(1);
            System.out.println(col1);
        }   
    }  
    
    public static void consultaintcompyeti () throws SQLException{
        String sql = "select b.Reg_Alias, c.Nombres_cliente, c.Apellidos_cliente from Tipo_de_Vehiculo a, Clientes c inner join Registro_intdecompra b on c.Alias = b.Reg_Alias where  b.Reg_Idtipodeveh = a.Idtipodeveh and a.Nombre_del_fabricante = 'Yeti' order by b.Reg_Alias;";
        Statement sentencia = Home.conexion().createStatement();
        ResultSet consulta = sentencia.executeQuery(sql);
        
        while (consulta.next()){
            String col1= consulta.getNString(1);
            String col2= consulta.getNString(2);
            String col3= consulta.getNString(3);
            System.out.println(col1 + " " + col2 + " " + col3);
        }   
    }  
    
    public static void consultaañofab () throws SQLException{
        String sql = "select count(Año_de_construccion) from bicicleta where Año_de_construccion >= '2019'";
        Statement sentencia = Home.conexion().createStatement();
        ResultSet consulta = sentencia.executeQuery(sql);
        
        while (consulta.next()){
            int col1= consulta.getInt(1);
            System.out.println(col1);
        }   
    }
    
}
