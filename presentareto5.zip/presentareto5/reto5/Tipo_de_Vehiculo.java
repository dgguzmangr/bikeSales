import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Tipo_de_Vehiculo {
    
    public static void IngresarTipodevehiculo() throws SQLException{
        String sql = "insert into Tipo_de_Vehiculo(Idtipodeveh, Nombre_del_fabricante) values(?,?)";
        PreparedStatement sentencia = Home.conexion().prepareStatement(sql);
        
        System.out.print("Id tipo de vehículo: ");
        int idtipodeveh = Home.sc.nextInt();
        sentencia.setInt(1, idtipodeveh);
        Home.sc.nextLine();
        
        System.out.print("Nombre: ");
        String fabricante = Home.sc.nextLine();
        sentencia.setString(2, fabricante);
        
        int Insertadas = sentencia.executeUpdate();
        if (Insertadas > 0) {
            System.out.println("Registros guardados exitosamente");
            System.out.println("--------------------------------");
        }
    }
}
