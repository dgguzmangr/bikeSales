import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Bicicleta {
    
    public static void IngresarBicicleta() throws SQLException {
        String sqlBici = "insert into Bicicleta (IdBicicleta,Precio_unitario_bicicleta,Año_de_construccion) values (?, ?, ?)";
        PreparedStatement senBici = Home.conexion().prepareStatement(sqlBici);
        
        System.out.print("IdBicicleta: ");
        int IdBicicleta = Home.sc.nextInt();
        senBici.setInt(1, IdBicicleta);
        Home.sc.nextLine();
                
        System.out.print("Precio_unitario_bicicleta: ");
        String PrecioBici = Home.sc.nextLine();
        senBici.setString(2, PrecioBici);
        
        System.out.print("Año_de_construccion: ");
        int Añodeconstruccion = Home.sc.nextInt();
        senBici.setInt(3, Añodeconstruccion);
        Home.sc.nextLine();
        
        int Insertadas = senBici.executeUpdate();
        if (Insertadas > 0) {
            System.out.println("Registros guardados exitosamente");
            System.out.println("--------------------------------");
        }
    }
}