import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Motocicleta_Electrica {
    
    public static void IngresarMotocicleta_Electrica() throws SQLException {
        String sqlBici = "INSERT INTO Motocicleta_Electrica VALUES (?, ?, ?, ?)";
        PreparedStatement senMoto = Home.conexion().prepareStatement(sqlBici);
        
        System.out.print("IdMoto: ");
        int idmoto = Home.sc.nextInt();
        senMoto.setInt(1, idmoto);
        Home.sc.nextLine();
                
        System.out.print("Precio moto: ");
        String Preciomoto = Home.sc.nextLine();
        senMoto.setString(2, Preciomoto);
        
        System.out.print("Autonomia_de_la_Bateria: ");
        String AutonomiaBateria = Home.sc.nextLine();
        senMoto.setString(3, AutonomiaBateria);
        
        System.out.print("Doc_proveedormotor: ");
        int Docproveedormotor = Home.sc.nextInt();
        senMoto.setInt(4, Docproveedormotor);
        Home.sc.nextLine();
        
        int Insertadas = senMoto.executeUpdate();
        if (Insertadas > 0) {
            System.out.println("Registros guardados exitosamente");
        }
    }
}